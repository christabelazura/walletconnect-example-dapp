# WalletConnect Example Dapp

## Develop

```bash
npm run start
```

## Test

```bash
npm run test
```

## Build

```bash
npm run build
```
